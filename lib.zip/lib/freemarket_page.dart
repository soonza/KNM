import 'package:flutter/material.dart';
import 'freemarket_write_page.dart'; // 글쓰기 페이지 임포트

class FreeMarketPage extends StatefulWidget {
  const FreeMarketPage({super.key});

  @override
  State<FreeMarketPage> createState() => _FreeMarketPageState();
}

class _FreeMarketPageState extends State<FreeMarketPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("자유시장"),
        centerTitle: true,
      ),
      body: Center( // 게시물이 없을 경우 메시지 표시
        child: const Text("게시물이 없습니다."), // 대체 메시지
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // 글쓰기 페이지로 이동
          Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => WritePostPage(), // WritePostPage로 업데이트
          ));
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
