import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io'; // File 클래스를 사용하기 위해 추가

class WritePostPage extends StatefulWidget {
  @override
  _WritePostPageState createState() => _WritePostPageState();
}

class _WritePostPageState extends State<WritePostPage> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController contentController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  List<XFile>? _imageFileList;

  Future<void> _pickImages() async {
    final List<XFile>? pickedFiles = await _picker.pickMultiImage();
    if (pickedFiles != null && pickedFiles.isNotEmpty) {
      setState(() {
        _imageFileList = pickedFiles;
      });
    }
  }

  void _createPost() {
    // 여기에 글 생성 로직 추가 (예: Firestore에 데이터 저장)
    // 데이터를 freemarket_page.dart에 전송하는 로직도 추가
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("글쓰기"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(
                labelText: "제목",
              ),
            ),
            const SizedBox(height: 16.0),
            TextField(
              controller: contentController,
              decoration: const InputDecoration(
                labelText: "내용",
              ),
              maxLines: 5,
            ),
            const SizedBox(height: 16.0),
            TextField(
              controller: priceController,
              decoration: const InputDecoration(
                labelText: "가격",
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _pickImages,
                  child: const Text("이미지 첨부"),
                ),
                ElevatedButton(
                  onPressed: _createPost,
                  child: const Text("글 생성"),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text("취소"),
                ),
              ],
            ),
            const SizedBox(height: 16.0),
            _imageFileList != null && _imageFileList!.isNotEmpty
                ? SizedBox(
                    height: 100, // 미리보기 이미지 높이
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _imageFileList!.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Image.file(
                            File(_imageFileList![index].path),
                            width: 80, // 미리보기 이미지 너비
                            height: 80, // 미리보기 이미지 높이
                            fit: BoxFit.cover,
                          ),
                        );
                      },
                    ),
                  )
                : const SizedBox.shrink(), // 이미지가 없을 경우 빈 공간
          ],
        ),
      ),
    );
  }
}
